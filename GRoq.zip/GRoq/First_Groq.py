
from openai import OpenAI
import os
client = OpenAI(
    #api_key=os.environ.get("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"),
    api_key="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",
    base_url="https://api.groq.com/openai/v1",
)

response = client.responses.create(
    input="Explain the importance of fast language models",
    model="openai/gpt-oss-20b",
)
print(response.output_text)
