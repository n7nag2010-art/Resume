from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# 1) Load embedding model (local, free)
model = SentenceTransformer("all-MiniLM-L6-v2")

# 2) Texts to embed
texts1 = [
    "LangChain helps you build LLM apps.",
    "Embeddings are useful for semantic search.",
    "I like to build AI applications with Python."
]

texts = [
    "TRICARE EAST - FOR ALL DOS"

]

# Convert to vectors
embeddings = model.encode(texts)

# 3) Query text
query = "How to build applications using LLMs?"
query = "PGBA,LLC."
query_emb = model.encode([query])

# 4) Compute similarity scores
scores = cosine_similarity(query_emb, embeddings)[0]

# Print results
for t, s in zip(texts, scores):
    print(f"Score: {s:.4f}   |   Text: {t}")

# 5) Get the best match
max_index = scores.argmax()          # index of highest score
best_text = texts[max_index]         # best matching text
best_score = scores[max_index]       # highest score value

print("\nBest Match:")
print(f"Score: {best_score:.4f}")
print(f"Text : {best_text}")

