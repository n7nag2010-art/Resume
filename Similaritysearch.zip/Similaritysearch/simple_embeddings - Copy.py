from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# 1) Load embedding model (local, free)
model = SentenceTransformer("all-MiniLM-L6-v2")

# 2) Texts to embed
texts1 = [
    "LangChain helps you build LLM apps.",
    "Embeddings are useful for semantic search.",
    "I like to build AI applications with Python."
]

texts = [
    "LangChain helps developers build applications powered by LLMs.",
    "Embeddings allow AI systems to understand semantic meaning.",
    "RAG improves accuracy by retrieving relevant documents before generating answers.",
    "Python is the most popular language for machine learning and AI.",
    "FAISS is a fast library for vector similarity search.",
    "Azure OpenAI provides enterprise-grade LLM models.",
    "Transformers use self-attention to process text.",
    "Semantic search finds meaning-based matches instead of keyword matches.",
    "ChromaDB is a simple local vector database for prototyping RAG systems.",
    "Pinecone is a managed vector database for large-scale workloads.",
    "GPT models can summarize long documents effectively.",
    "Sentence Transformers provide high-quality embedding models.",
    "Vector similarity is often computed using cosine similarity.",
    "Fine-tuning can improve model performance on domain-specific tasks.",
    "Streamlit can be used to build simple AI-powered web apps.",
    "OpenAI embeddings are great for semantic search and clustering.",
    "Hugging Face provides thousands of NLP and embedding models.",
    "Generative AI can assist with automating repetitive tasks.",
    "Large Language Models learn patterns from massive datasets.",
    "Prompt engineering helps guide LLMs to generate better responses."
]


# Convert to vectors
embeddings = model.encode(texts)

# 3) Query text
query = "How to build applications using LLMs?"
query = "Hugging Face  free nlp and modul "
query_emb = model.encode([query])

# 4) Compute similarity scores
scores = cosine_similarity(query_emb, embeddings)[0]

# Print results
for t, s in zip(texts, scores):
    print(f"Score: {s:.4f}   |   Text: {t}")

# 5) Get the best match
max_index = scores.argmax()          # index of highest score
best_text = texts[max_index]         # best matching text
best_score = scores[max_index]       # highest score value

print("\nBest Match:")
print(f"Score: {best_score:.4f}")
print(f"Text : {best_text}")

