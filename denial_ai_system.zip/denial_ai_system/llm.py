# llm.py

from langchain.chat_models import ChatOpenAI

def get_llm():
    return ChatOpenAI(
        model="gpt-5-chat",
        temperature=0
    )