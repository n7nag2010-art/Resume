# main.py

from agents import intake_agent
from graph import build_graph

def run():

    # Sample claim (835-like)
    claim = {
        "id": "C1001",
        "paid_amount": 0,
        "carc_code": "CO-16"
    }

    # Step 1: Intake
    state = intake_agent(claim)

    # Step 2: Run LangGraph
    app = build_graph()
    result = app.invoke(state)

    print("\n✅ FINAL RESULT:\n")
    for k, v in result.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    run()
``