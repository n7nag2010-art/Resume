# agents.py

from langchain.chains import LLMChain
from llm import get_llm
from prompts import classification_prompt, rca_prompt, action_prompt

llm = get_llm()

# Initialize chains (agents)
classification_chain = LLMChain(llm=llm, prompt=classification_prompt)
rca_chain = LLMChain(llm=llm, prompt=rca_prompt)
action_chain = LLMChain(llm=llm, prompt=action_prompt)


# ----- AGENTS -----

def intake_agent(claim):
    return {
        "claim_id": claim["id"],
        "carc_code": claim["carc_code"],
        "paid_amount": claim["paid_amount"]
    }


def classification_agent(state):
    category = classification_chain.run(carc_code=state["carc_code"])
    state["category"] = category.strip()
    return state


def rca_agent(state):
    root_cause = rca_chain.run(
        carc_code=state["carc_code"],
        category=state["category"]
    )
    state["root_cause"] = root_cause.strip()
    return state


def action_agent(state):
    action = action_chain.run(root_cause=state["root_cause"])
    state["action"] = action.strip()
    return state


def routing_agent(state):
    mapping = {
        "Eligibility": "Front Desk",
        "Billing": "AR Team",
        "Coding": "Coding Team",
        "Medical": "Clinical Team"
    }

    state["assigned_to"] = mapping.get(state["category"], "General Queue")
    return state
``