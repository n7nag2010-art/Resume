# agents.py

from langchain.chains import LLMChain
from llm import get_llm
from prompts import classification_prompt, rca_prompt, action_prompt
from rag import retrieve_rules
llm = get_llm()

# Initialize chains (agents)
classification_chain = LLMChain(llm=llm, prompt=classification_prompt)
rca_chain = LLMChain(llm=llm, prompt=rca_prompt)
action_chain = LLMChain(llm=llm, prompt=action_prompt)


# ----- AGENTS -----

def intake_agent(claim):
    return {
        "claim_id": claim["id"],
        "carc_code": claim["carc_code"],
        "paid_amount": claim["paid_amount"]
    }


def classification_agent(state):
    category = classification_chain.run(carc_code=state["carc_code"])
    state["category"] = category.strip()
    return state



def rca_agent(state):

    rules = retrieve_rules(
        state["carc_code"],
        state.get("payer", "Medicare")
    )

    prompt = f"""
    You are an RCM expert.

    Denial Code: {state['carc_code']}
    Category: {state['category']}

    Payer Rules:
    {rules}

    Identify accurate root cause.
    """

    root_cause = rca_chain.run(prompt)
    state["root_cause"] = root_cause.strip()
    return state


def action_agent(state):

    rules = retrieve_rules(
        state["carc_code"],
        state.get("payer", "Medicare")
    )

    prompt = f"""
    Suggest best action based on:

    Root Cause: {state['root_cause']}

    Payer Rules:
    {rules}

    Actions: Rebill / Appeal / Correct / Write-off
    """

    action = action_chain.run(prompt)
    state["action"] = action.strip()
    return state



def routing_agent(state):
    mapping = {
        "Eligibility": "Front Desk",
        "Billing": "AR Team",
        "Coding": "Coding Team",
        "Medical": "Clinical Team"
    }

    state["assigned_to"] = mapping.get(state["category"], "General Queue")
    return state
``