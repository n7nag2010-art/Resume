# rag.py

import json

# Load rules
def load_rules():
    with open("payer_rules.json", "r") as f:
        return json.load(f)


rules_db = load_rules()


def retrieve_rules(carc_code, payer):
    results = []

    for rule in rules_db:
        if rule["code"] == carc_code and rule["payer"] == payer:
            results.append(rule["rule"])

    return results if results else ["No specific rule found"]