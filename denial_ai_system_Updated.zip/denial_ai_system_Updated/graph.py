# graph.py

from typing import TypedDict
from langgraph.graph import StateGraph

from agents import (
    classification_agent,
    rca_agent,
    action_agent,
    routing_agent
)


# Define state
class DenialState(TypedDict):
    claim_id: str
    carc_code: str
    paid_amount: int
    category: str
    root_cause: str
    action: str
    assigned_to: str


def build_graph():

    graph = StateGraph(DenialState)

    # Add nodes
    graph.add_node("classification", classification_agent)
    graph.add_node("rca", rca_agent)
    graph.add_node("action", action_agent)
    graph.add_node("routing", routing_agent)

    # Flow
    graph.set_entry_point("classification")
    graph.add_edge("classification", "rca")
    graph.add_edge("rca", "action")
    graph.add_edge("action", "routing")

    graph.set_finish_point("routing")

    return graph.compile()