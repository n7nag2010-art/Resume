# prompts.py

from langchain_core.prompts import PromptTemplate

classification_prompt = PromptTemplate(
    input_variables=["carc_code"],
    template="""
    Classify denial into:
    Eligibility / Billing / Coding / Medical

    Denial Code: {carc_code}
    """
)

rca_prompt = PromptTemplate(
    input_variables=["carc_code", "category"],
    template="""
    Identify root cause for denial.

    Denial Code: {carc_code}
    Category: {category}
    """
)

action_prompt = PromptTemplate(
    input_variables=["root_cause"],
    template="""
    Suggest best action:
    Rebill / Appeal / Correct Data / Write-off

    Root Cause: {root_cause}
    """
)