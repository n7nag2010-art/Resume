# llm.py

from langchain_openai import ChatOpenAI

def get_llm():
    return ChatOpenAI(
        model="openai/gpt-oss-20b",
        openai_api_key="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",
        openai_api_base="https://api.groq.com/openai/v1",
        temperature=0
    )